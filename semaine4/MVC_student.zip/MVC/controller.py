
class Controller:

    def __init__(self, model, view):

        self.__view = view
        self.__model = model
        self.__CELSIUS = "°C"
        self.__FARENHEIT = "°F"

        #Binding
        self.__view.update(str(self.__model.getTemperature()) + self.__CELSIUS)

        #callback
        self.__view.increase_btn.config(command = self.increase)
        self.__view.farenheit_btn.config(command = self.farenheit)

    def increase(self) -> None:

        self.__model.increase()
        self.__view.update(str(self.__model.getTemperature()) + self.getUnit())

    def farenheit(self) -> None:

        if self.getUnit() == self.__CELSIUS:
            self.__model.farenheit()
            self.__view.update(str(self.__model.getTemperature()) + self.__FARENHEIT)

    def getUnit(self) -> str:
        
        return self.__view.temperature_lbl['text'][-2:]