
class Controller:

    def __init__(self, model, view):

        self.__view = view
        self.__model = model
        self.__CELSIUS = "°C"
        self.__FARENHEIT = "°F"

        #Binding
        self.__view.update(str(self.__model.getTemperature()) + self.__CELSIUS)

        #callback
        self.__view.increase_btn.config(command = self.increase)
        self.__view.farenheit_btn.config(command = self.farenheit)

    def increase(self) -> None:
        pass

    def farenheit(self) -> None:
        pass

    def getUnit(self) -> str:
        
        return self.__view.temperature_lbl['text'][-2:]
