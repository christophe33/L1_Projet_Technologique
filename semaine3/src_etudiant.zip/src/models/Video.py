class Video:

    def __init__(self):
        pass


