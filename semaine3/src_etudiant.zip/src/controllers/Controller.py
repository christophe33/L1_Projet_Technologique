import tkinter as tk

class Controller:

    def __init__(self, video, view):
        
        self.video = video
        self.view = view
        
            
            

        

        