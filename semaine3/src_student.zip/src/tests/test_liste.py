import unittest
import sys
sys.path.append("../")
from liste.liste import liste, cell

class Test_liste(unittest.TestCase):

    def setUp(self) -> None:
        self.__liste = liste()
        self.__first = cell("first")
        self.__second = cell("second")
        self.__third = cell("third")

    def tearDown(self):
        self.__liste == liste()
        
    def test_add_isEmpty(self):
        self.assertTrue(self.__liste)

    def test_addFirstWithEmptyList(self):       
        self.__liste.addFirst(self.__first)
        self.assertTrue(self.__liste.getFirst() is self.__first)

    def test_addLastWithEmptyList(self):
        self.__liste.addLast(self.__second)
        self.assertTrue(self.__liste.getFirst() is self.__second)

    def test_addFirst(self):
        self.__liste.addFirst(self.__first)
        self.__liste.addFirst(self.__second)
        self.assertTrue(self.__liste.getFirst() is self.__second)
        self.assertTrue(self.__liste.getLast() is self.__first)

if __name__ == '__main__':
    unittest.main()